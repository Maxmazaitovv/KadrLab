# KadrLab — Stage 2

Android app prototype for planning short videos.

## Included in this stage
- Studio: idea, visual style, duration and aspect-ratio selection
- AI Director workspace: editable storyboard scene list
- Timeline: scene order, project name and audio/export planning panels
- Projects screen
- GitHub Actions workflow that builds a debug APK

## Build
Requires JDK 17 and Gradle 8.11.1:
```bash
gradle :app:assembleDebug
```
APK: `app/build/outputs/apk/debug/app-debug.apk`

## Important
This is a UI and editing-workflow prototype. It does not yet call a generative AI service, synthesize voice, render animations, or export MP4. Those require a backend/AI provider and the next implementation stage.
